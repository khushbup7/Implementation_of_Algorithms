// Ver 1.0:  Index interface
// @author rbk

package cs6301.g39;

public interface Index {
	public void putIndex(int index);

	public int getIndex();
}
